var express = require('express');
var router = express.Router();

/* GET users listing. */
router.get('/', function (req, res, next) {
    res.send({
        ladies: [{
            type1: {
                size:'xyz',
                cplor:'pink'
            },
            type2: {
                size:'abc',
                cplor:'red'
            }
        }]
    });
});

module.exports = router;